from nornir import InitNornir
from nornir_napalm.plugins.tasks import napalm_get

import pprint

nr = InitNornir(config_file="config.yaml")
br = nr.filter(name="br1")
r = br.run(
    task=napalm_get,
    getters=["facts"]
)
pprint.pprint(r["br1"][0].result)
